Portfolio
Udacity Portfolio project for the Full Stack-1  Nanodegree.
Project created using Flexbox and Media Queries for its responsiveness.
